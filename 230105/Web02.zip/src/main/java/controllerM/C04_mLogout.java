package controllerM;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.MemberService;
import vo.MemberVO;
 
// ** Member Login
 
@WebServlet("/logout")
public class C04_mLogout extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public C04_mLogout() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 1) 요청분석 & 해당하는 Service 실행
		// => Logout: session 무효화, index
		// => session 객체 정의
		//	-> request.getSession() 메서드의 매개변수 사용
		//	-> 매개변수 없음과 true 는 동일 : session이 없을때 생성해서 제공 -> 그러므로 session이 null인 경우없음
		//	-> false : session이 없을때는 null return
		//				(사용전에 반드시 null 확인해야함 -> NullPointerException 예방)
		
		HttpSession session = request.getSession(false);
		if ( session !=null ) {
			session.invalidate(); // session 무효화
			request.setAttribute("message", "~~ Logout 성공 ~~");
		}
	 
		String uri="index.jsp" ;
		
		// 2) View 로 Forward
		request.getRequestDispatcher(uri).forward(request, response);
		 
	} //doGet

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
} //class
