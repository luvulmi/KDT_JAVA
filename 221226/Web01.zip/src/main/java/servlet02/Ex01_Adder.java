package servlet02;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/adder")
public class Ex01_Adder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Ex01_Adder() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1) request ó��

		// 2) Service : add ����

		// 3) View ó�� : ������ ���

		// => Parameter_Data ó�� & ���� ����
		int number1 = Integer.parseInt(request.getParameter("num1")); // String -> int ����ȯ.
		int number2 = Integer.parseInt(request.getParameter("num2")); // String -> int ����ȯ.

		// => ������ (response) ó��
		// => response : �ѱ� ó��.
		response.setContentType("text/html; charset=UTF-8");
		// ** response ContentType ����

		// => ��°�ü ����
		PrintWriter out = response.getWriter();
		out.print("<html><body><h2 style='color:purple;'>** Form Data ó�� 01 : Adder **</h2>");

		out.print("** Number1 : " + number1 + "<br>");
		out.print("** Number2 : " + number2 + "<br>");
		out.print("** add : " + (number1 + number2) + "<br>");

		out.print("</body></html>");

	}// doGet

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}// class
