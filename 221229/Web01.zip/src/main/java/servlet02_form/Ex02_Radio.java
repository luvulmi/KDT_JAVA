package servlet02_form;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/radio")
public class Ex02_Radio extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Ex02_Radio() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String gender = request.getParameter("gender");
		String mailcheck = request.getParameter("mailcheck");
		String hello = request.getParameter("content");
		
		if(mailcheck.equals("yes")) mailcheck = "���ŵ���";
		else mailcheck = "���� ����";
		
		
		response.setContentType("text/html; charset=UTF-8");


		// => ��°�ü ����
		PrintWriter out = response.getWriter();
		out.print("<html><body><h2 style='color:purple;'>** RadioButton Test **</h2>");

		out.print("** ���� : " + gender +"<br>");
		out.print("** ���� : " + mailcheck + "<br>");
		out.print("** �λ� : " + hello + "<br>");
		out.print("<br><br><h2><a href='javascript:history.go(-1)'>�ٽ� �Է��ϱ�</a></h2>");		

		out.print("</body></html>");

	}// doGet

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1) ��û�м�
		// => �ѱ�Ȯ�� (get: )
		request.setCharacterEncoding("UTF-8");
		
		String gender = request.getParameter("gender");
		String mailcheck = request.getParameter("mailcheck");
		String hello = request.getParameter("content");
		
		if(mailcheck.equals("yes")) mailcheck = "���ŵ���";
		else mailcheck = "���� ����";
		
		response.setContentType("text/html; charset=UTF-8");


		// => ��°�ü ����
		PrintWriter out = response.getWriter();
		out.print("<html><body><h2 style='color:purple;'>** RadioButton Test **</h2>");

		out.print("** ���� : " + gender +"<br>");
		out.print("** ���� : " + mailcheck + "<br>");
		out.print("** �λ� : " + hello + "<br>");
		out.print("<br><br><h2><a href='javascript:history.go(www.naver.com)'>�ٽ� �Է��ϱ�</a></h2>");		

		out.print("</body></html>");
		doGet(request, response);
	}
}
