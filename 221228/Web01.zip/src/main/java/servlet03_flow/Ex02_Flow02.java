package servlet03_flow;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/flow02")
public class Ex02_Flow02 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Ex02_Flow02() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		int page = Integer.parseInt(request.getParameter("page"));
		String send = request.getParameter("send");
		String add = "";
		
		switch (page) {
		case 1:
			add = "hello";
			break;
		case 2:
			add = "gugu";
			break;
		case 3:
			add = "servletTestForm/form03_Check.jsp";
			break;
		case 4:
			add = "servletTestForm/form04_Select.jsp";
			break;		
		}

		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("<h2>** Forward & Redirect </h2>");

		if("f".equals(send)) { // ** NullPointException ���� 
			request.getRequestDispatcher(add).forward(request, response);
		} else {
			response.sendRedirect(add);
		}

	}

}
