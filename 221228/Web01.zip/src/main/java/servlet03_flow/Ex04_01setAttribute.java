package servlet03_flow;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//** Attribute ����
//=> setAttribute("Attribute Name", Value_ObjectType)    
//=> �� ȯ�濡�� �����Ǵ� �⺻��ü�� (request, response, out, session ....) ��
// page, request, session, application �� �� ��������  
//=> removeAttribute("message") : ��������

@WebServlet("/01seta")
public class Ex04_01setAttribute extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Ex04_01setAttribute() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		// 1) Parameter ó��
		// => form ���� ������Ʈ������ Test
		//		~~/01seta?id=banana&num=1234&name=ȫ�浿
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		int num = Integer.parseInt(request.getParameter("num"));
		System.out.println("** setAttribute Test **");
		System.out.printf("** Parameter: id=%s, name=%s, num=%d \n", id,name,num);
		
		// 2) setAttribute �� �����ϱ�
		// => request
		request.setAttribute("rid", id);
		request.setAttribute("rname", name);
		request.setAttribute("rnum", num);
		
		// => session
		HttpSession session = request.getSession();
		session.setAttribute("sid", id);
		session.setAttribute("sname", name);
		session.setAttribute("snum", num);
		
		// 3) �̵� �� (02geta) �����س��� Attribute Ȯ���ϱ�
		String uri = "02geta";
		
		// => forward
//		request.getRequestDispatcher(uri).forward(request, response);
		
		// => redirect
		// => ��� ����
		//		-> forward�� �ٸ���
		//		-> �ƴϴ� : 1) F, 2) F, 3) T
		response.sendRedirect(uri);
		
	}//doGet

}//class
