package servlet02_form;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reqinfo")
public class Ex05_RequestInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Ex05_RequestInfo() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ** �⺻ ȭ�� ���
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("<html><body>");
		out.print("<h2>** Request Information Test **</h2>");
		out.print("<h3> 1) �ֿ� �޼���</h3>");
		out.print("<h3> 2) Request Header Name & Values</h3>");
		out.print("<h3> 3) ContextPath : �����ø����̼��� �ֻ��� ���</h3>");
		out.print("<h3> 4) RealPath: �����ø����̼��� ������ġ</h3>");
		out.print("<h3> 5) ��Ÿ ��� </h3>");
		out.print("<h3> => Console â���� Ȯ�����ּ���~</h3>");
		out.print("</body></html>");

		// ** Console ���
		System.out.println("** 1) Request Header Name & Values **");
		Enumeration<String> hNames = request.getHeaderNames();
		while (hNames.hasMoreElements()) {
			String hName = hNames.nextElement();
			String hValue = request.getHeader(hName);
			System.out.println(hName + "=> " + hValue);
		}
		System.out.println("** 2) ContextPath : �����ø����̼��� �ֻ��� ��� **");
		System.out.println("   => " + request.getContextPath());
		System.out.println("** 3) RealPath: �����ø����̼��� ������ġ **");
		System.out.println("   => " + request.getRealPath("/"));
		System.out.println("** 4) ��Ÿ ���  **");
		System.out.println("   => RemoteAddr: " + request.getRemoteAddr());
		System.out.println("   => Method: " + request.getMethod());
		System.out.println("   => RequestURL: " + request.getRequestURL());
		System.out.println("   => RequestURI: " + request.getRequestURI());
		System.out.println("   => ServerName: " + request.getServerName());
		System.out.println("   => ServerPort: " + request.getServerPort());
		System.out.println("   => ServletPath: " + request.getServletPath());

		// ** Console ���

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}// class
